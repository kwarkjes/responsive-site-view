angular.module('rsv.chromeApiService', []).factory('chromeApiService', function () {
    return chrome;
});