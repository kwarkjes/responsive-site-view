angularjs-element-snap-shot
===========================

An AngularJS directive for Chrome extensions which allows an image to be captured of the element it is placed on and returned to a model or output in a new window.

##Usage
````html
<div id="myElement" ng-model="myImageData" nim-element-snap-shot="mySnapShotFunction">
  Content goes here
</div>
````
Add the directive to the element you want to be able to capture an image of. Specify the name of the function here that you want to use to trigger the image capture, in the example I've used mySnapShotFunction. The image will be saved as a base64 encoded string to the specified ngModel. Make sure the element has an id as this helps the directive ensure the element is pulled into the visable area and can therefore be captured.

The snapshot function can be called from a controller or can be triggered in an event handler:

````js
.controller('myController', function ($scope){
  $scope.mySnapShotFunction();
});
````
````html
<button ng-click="mySnapShotFunction">Snapshot</button>
````

Providing the attribute nim-element-snap-shot-newwindow will pop open a new tab containing the captured image.

````html
<div id="myElement" ng-model="myImageData" nim-element-snap-shot="mySnapShotFunction" nim-element-snap-shot-newwindow="true">
  Content goes here
</div>
````
